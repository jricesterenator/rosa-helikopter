socat PTY,link=/tmp/fake1,raw,echo=0 PTY,link=/tmp/fake2,raw,ech0=0
python `dirname $0`/qc.py
