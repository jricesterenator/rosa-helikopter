class MockARDrone:

    def takeoff(self):
        pass

    def land(self):
        pass

    def hover(self):
        pass

    def move_left(self):
        pass

    def move_right(self):
        pass

    def move_up(self):
        pass

    def move_down(self):
        pass

    def move_forward(self):
        pass

    def move_backward(self):
        pass

    def turn_left(self):
        pass

    def turn_right(self):
        pass

    def reset(self):
        pass

    def trim(self):
        pass

    def set_speed(self, speed):
        pass