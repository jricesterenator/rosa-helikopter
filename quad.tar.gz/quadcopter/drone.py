class Drone:

    def __init__(self, drone):
        self.drone = drone

    def takeoff(self, value):
        print "Take Off!"
        self.drone.takeoff()

    def land(self, value):
        print "Land!"
        self.drone.land()